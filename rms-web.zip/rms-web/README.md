# Restaurant Management System (HTML, CSS, JavaScript)

Browser-only restaurant app: tables, orders, billing (discount, then 5% tax), menu, reservations with clash checks, daily report and CSV export. Data is saved in the browser (localStorage), so it needs no server.

**Run:** open `index.html`. **Host free:** GitHub repo > Settings > Pages > Deploy from branch `main` / root.

Demo logins: admin/admin123, waiter/waiter123, cashier/cashier123. Roles limit what each user can do.

Note: logins are a front-end demo only and not secure. For real security use the Python/Flask version.
