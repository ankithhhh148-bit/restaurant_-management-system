"use strict";
const KEY = "rms_v1", SEATS = [2,2,2,2,4,4,4,4,6,6], TAX = 0.05;
const USERS = {admin:"admin123", waiter:"waiter123", cashier:"cashier123"};
const MENU = [["Hot Coffee","Coffee",100],["Cold Coffee","Coffee",150],["Cheese Pasta","Pasta",200],["Normal Pasta","Pasta",150],["Veg Burger","Burger",100],["Chicken Burger","Burger",180],["Chilli Chicken (Half)","Chicken",200],["Chilli Chicken (Full)","Chicken",390],["Tandoori Chicken (Half)","Chicken",250],["Tandoori Chicken (Full)","Chicken",480]];
const seed = () => ({menu: MENU.map((m,i) => ({id:i+1,name:m[0],cat:m[1],price:m[2],on:true})), orders:[], res:[], n:{o:1,r:1,m:11}});
let db = JSON.parse(localStorage.getItem(KEY) || "null") || seed();
let user = sessionStorage.getItem("rms_user"), view = "tables", cur = null, msg = "", err = false;
const $ = s => document.querySelector(s), save = () => localStorage.setItem(KEY, JSON.stringify(db));
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const r2 = x => Math.round((x + Number.EPSILON) * 100) / 100, inr = x => "\u20B9" + Number(x).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2});
const bill = (sub, d) => { const disc = r2(sub*d/100), tax = r2((sub-disc)*TAX); return {sub:r2(sub), disc, tax, total:r2(sub-disc+tax)}; };
const sub = o => o.items.reduce((s,i) => s + i.price*i.qty, 0);
const stamp = () => { const d = new Date(); return d.toLocaleDateString("en-CA") + " " + d.toTimeString().slice(0,5); };
const can = (...r) => r.includes(user), open = t => db.orders.find(o => o.table === t && o.status === "open");
const say = (m, e=false) => { msg = m; err = e; };
const PAGES = {tables:["admin","waiter","cashier"], menu:["admin","waiter","cashier"], reservations:["admin","waiter","cashier"], report:["admin","cashier"]};

function tableState(t) {
  if (open(t)) return "occupied";
  const now = Date.now();
  return db.res.some(r => r.table === t && r.on && new Date(r.slot) - now < 3600e3 && new Date(r.slot) - now > -1800e3) ? "reserved" : "free";
}
const views = {
  tables: () => `<h2>Tables</h2><div class="grid">${SEATS.map((s,i) => { const t=i+1, st=tableState(t), o=open(t);
    return `<div class="t ${st}"><b>Table ${t}</b><div class="m">${s} seats &middot; ${st}${o ? " &middot; " + inr(sub(o)) : ""}</div><p>${o
      ? `<button class="b" data-act="order" data-id="${o.id}">View order</button>`
      : can("admin","waiter") ? `<button class="b p" data-act="openT" data-t="${t}">Open order</button>` : ""}</p></div>`; }).join("")}</div>`,
  order: () => { const o = db.orders.find(x => x.id === cur); if (!o) return views.tables();
    const edit = o.status === "open" && can("admin","waiter");
    return `<h2>Order #${o.id} &middot; Table ${o.table}</h2>${edit ? `<form class="card row" data-form="add"><div><label>Dish<br><select name="item">${db.menu.filter(m=>m.on).map(m=>`<option value="${m.id}">${esc(m.name)} - ${inr(m.price)}</option>`).join("")}</select></label></div>
      <label>Qty<br><input name="qty" type="number" min="1" max="99" value="1" style="width:80px"></label><button class="b p">Add</button></form>` : ""}
    <div class="card"><table><tr><th>Dish</th><th class="r">Qty</th><th class="r">Total</th><th></th></tr>${o.items.map((i,k)=>`<tr><td>${esc(i.name)}</td><td class="r">${i.qty}</td><td class="r">${inr(i.price*i.qty)}</td><td class="r">${edit ? `<button class="b d" data-act="rm" data-k="${k}">Remove</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="4" class="m">No items yet</td></tr>`}</table>
    <div class="tot"><div class="g"><span>Subtotal</span><span>${inr(sub(o))}</span></div></div></div>
    ${o.status === "open" ? `${can("admin","cashier") && o.items.length ? `<button class="b p" data-act="bill">Generate bill</button> ` : ""}${edit ? `<button class="b d" data-act="cancel">Cancel order</button>` : ""}` : receipt(o)}`; },
  bill: () => { const o = db.orders.find(x => x.id === cur), b = bill(sub(o), 0);
    return `<h2>Bill &middot; Order #${o.id}</h2><div class="card"><table>${o.items.map(i=>`<tr><td>${esc(i.name)} x ${i.qty}</td><td class="r">${inr(i.price*i.qty)}</td></tr>`).join("")}</table>
    <div class="tot"><div><span>Subtotal</span><span id="vs">${inr(b.sub)}</span></div><div><span>Discount</span><span id="vd">-${inr(0)}</span></div><div><span>Tax 5%</span><span id="vt">${inr(b.tax)}</span></div><div class="g"><span>Total</span><span id="vg">${inr(b.total)}</span></div></div></div>
    <form class="card row" data-form="pay"><label>Discount %<br><input id="disc" name="disc" type="number" min="0" max="100" step="0.01" value="0" style="width:100px"></label>
    <label>Payment<br><select name="method"><option>cash</option><option>upi</option><option>card</option></select></label><button class="b p">Mark as paid</button></form>`; },
  menu: () => `<h2>Menu</h2>${can("admin") ? `<form class="card row" data-form="dish"><label>Name<br><input name="name" required></label><label>Category<br><input name="cat" required></label><label>Price<br><input name="price" type="number" step="0.01" min="0" required style="width:100px"></label><button class="b p">Add dish</button></form>` : ""}
    <div class="card"><table><tr><th>Name</th><th>Category</th><th class="r">Price</th><th>Status</th><th></th></tr>${db.menu.map(m=>`<tr><td>${esc(m.name)}</td><td>${esc(m.cat)}</td><td class="r">${inr(m.price)}</td><td>${m.on?"Available":"Hidden"}</td><td class="r">${can("admin") ? `<button class="b" data-act="tog" data-id="${m.id}">${m.on?"Hide":"Show"}</button> <button class="b d" data-act="del" data-id="${m.id}">Delete</button>` : ""}</td></tr>`).join("")}</table></div>`,
  reservations: () => `<h2>Reservations</h2>${can("admin","waiter") ? `<form class="card row" data-form="res"><label>Table<br><select name="table">${SEATS.map((s,i)=>`<option value="${i+1}">Table ${i+1} (${s} seats)</option>`).join("")}</select></label><label>Guests<br><input name="guests" type="number" min="1" value="2" style="width:80px"></label>
    <label>Date &amp; time<br><input name="slot" type="datetime-local" required></label><label>Name<br><input name="name" required></label><label>Phone<br><input name="phone" required></label><button class="b p">Reserve</button></form>` : ""}
    <div class="card"><table><tr><th>Slot</th><th>Table</th><th>Guests</th><th>Customer</th><th>Phone</th><th></th></tr>${db.res.filter(r=>r.on).sort((a,b)=>a.slot.localeCompare(b.slot)).map(r=>`<tr><td>${esc(r.slot.replace("T"," "))}</td><td>${r.table}</td><td>${r.guests}</td><td>${esc(r.name)}</td><td>${esc(r.phone)}</td><td class="r">${can("admin","waiter") ? `<button class="b d" data-act="cres" data-id="${r.id}">Cancel</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="6" class="m">No reservations</td></tr>`}</table></div>`,
  report: () => { const d = new Date().toLocaleDateString("en-CA"), paid = db.orders.filter(o => o.status === "paid" && o.paidAt.startsWith(d)), rev = r2(paid.reduce((s,o)=>s+o.total,0)), top = {};
    paid.forEach(o => o.items.forEach(i => top[i.name] = (top[i.name]||0) + i.qty));
    return `<h2>Daily sales report &middot; ${d}</h2><div class="card"><b>Paid orders:</b> ${paid.length} &nbsp; <b>Revenue:</b> ${inr(rev)} &nbsp; <b>Average bill:</b> ${inr(paid.length ? rev/paid.length : 0)}</div>
    <div class="card"><h2>Top items</h2><table>${Object.entries(top).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,q])=>`<tr><td>${esc(n)}</td><td class="r">${q}</td></tr>`).join("") || `<tr><td class="m">No sales today</td></tr>`}</table></div><button class="b" data-act="csv">Export all paid orders (CSV)</button>`; }
};
const receipt = o => `<div class="card"><h2>Receipt</h2><div class="tot" style="margin:0"><div><span>Subtotal</span><span>${inr(o.subtotal)}</span></div><div><span>Discount ${o.discount}%</span><span>-${inr(r2(o.subtotal*o.discount/100))}</span></div><div><span>Tax 5%</span><span>${inr(o.tax)}</span></div><div class="g"><span>Total (${o.method})</span><span>${inr(o.total)}</span></div></div><p><button class="b" onclick="window.print()">Print</button></p></div>`;

function render() {
  if (!user) { $("#nav").innerHTML = ""; $("#app").innerHTML = `<form class="card login" data-form="login"><h2>Sign in</h2>${msg ? `<div class="msg err">${esc(msg)}</div>` : ""}<input name="u" placeholder="Username" required><input name="p" type="password" placeholder="Password" required><button class="b p" style="width:100%">Log in</button>
    <p class="m">Demo logins: admin/admin123, waiter/waiter123, cashier/cashier123</p></form>`; msg = ""; return; }
  $("#nav").innerHTML = Object.keys(PAGES).filter(p => can(...PAGES[p])).map(p => `<button class="${view===p?"on":""}" data-act="nav" data-v="${p}">${p[0].toUpperCase()+p.slice(1)}</button>`).join("") + `<button data-act="reset">Reset demo</button><button data-act="logout">Log out (${user})</button>`;
  $("#app").innerHTML = (msg ? `<div class="msg ${err?"err":""}">${esc(msg)}</div>` : "") + views[view](); msg = "";
}
const go = (v, m, e) => { view = v; if (m) say(m, e); save(); render(); };
const acts = {
  nav: d => go(d.v), logout: () => { sessionStorage.removeItem("rms_user"); user = null; render(); },
  reset: () => { if (confirm("Reset all demo data?")) { db = seed(); go("tables", "Demo data reset."); } },
  openT: d => { if (!can("admin","waiter")) return; const t = +d.t; if (!open(t)) { db.orders.push({id:db.n.o++, table:t, items:[], status:"open", createdAt:stamp()}); } cur = open(t).id; go("order"); },
  order: d => { cur = +d.id; go("order"); },
  rm: d => { const o = db.orders.find(x=>x.id===cur); if (o.status==="open") o.items.splice(+d.k,1); go("order"); },
  cancel: () => { if (confirm("Cancel this order?")) { db.orders = db.orders.filter(o => o.id !== cur); go("tables", "Order cancelled."); } },
  bill: () => go("bill"),
  tog: d => { const m = db.menu.find(x=>x.id===+d.id); m.on = !m.on; go("menu"); },
  del: d => { if (db.orders.some(o => o.items.some(i => i.id === +d.id))) return go("menu", "Used in past orders - hide it instead.", true); db.menu = db.menu.filter(m=>m.id!==+d.id); go("menu"); },
  cres: d => { db.res.find(r=>r.id===+d.id).on = false; go("reservations", "Reservation cancelled."); },
  csv: () => { const rows = [["order","table","paid_at","method","subtotal","discount_pct","tax","total"]].concat(db.orders.filter(o=>o.status==="paid").map(o=>[o.id,o.table,o.paidAt,o.method,o.subtotal,o.discount,o.tax,o.total]));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map(r=>r.join(",")).join("\n")],{type:"text/csv"})); a.download = "sales.csv"; a.click(); }
};
const forms = {
  login: f => { if (USERS[f.u] && USERS[f.u] === f.p) { user = f.u; sessionStorage.setItem("rms_user", user); view = "tables"; render(); } else { say("Invalid username or password.", true); render(); } },
  add: f => { const o = db.orders.find(x=>x.id===cur), m = db.menu.find(x=>x.id===+f.item && x.on), q = parseInt(f.qty, 10);
    if (!m || !(q >= 1 && q <= 99)) return go("order", "Choose a dish and a quantity from 1 to 99.", true);
    const l = o.items.find(i => i.id === m.id); l ? l.qty = Math.min(99, l.qty + q) : o.items.push({id:m.id, name:m.name, price:m.price, qty:q}); go("order", `Added ${q} x ${m.name}.`); },
  pay: f => { const o = db.orders.find(x=>x.id===cur), d = parseFloat(f.disc);
    if (o.status !== "open") return go("order", "Already paid.", true);
    if (!(d >= 0 && d <= 100)) return go("bill", "Discount must be 0 to 100.", true);
    const b = bill(sub(o), d); Object.assign(o, {status:"paid", paidAt:stamp(), subtotal:b.sub, discount:d, tax:b.tax, total:b.total, method:f.method}); go("order", "Payment recorded. Table is now free."); },
  dish: f => { const p = parseFloat(f.price); if (!f.name.trim() || !f.cat.trim() || !(p >= 0)) return go("menu", "Fill all fields with a valid price.", true);
    if (db.menu.some(m => m.name.toLowerCase() === f.name.trim().toLowerCase())) return go("menu", "That dish already exists.", true);
    db.menu.push({id:db.n.m++, name:f.name.trim(), cat:f.cat.trim(), price:p, on:true}); go("menu", "Dish added."); },
  res: f => { const t = +f.table, g = parseInt(f.guests,10), at = new Date(f.slot), digits = f.phone.replace(/\D/g,"");
    const bad = isNaN(at) ? "Enter a date and time." : at < new Date() ? "That time is in the past." : !(g >= 1) ? "Guests must be at least 1." : g > SEATS[t-1] ? `Table ${t} seats ${SEATS[t-1]} people.` : (digits.length < 7 || digits.length > 15) ? "Enter a valid phone number."
      : db.res.some(r => r.on && r.table === t && Math.abs(new Date(r.slot) - at) < 90*60e3) ? `Table ${t} is already booked around that time.` : "";
    if (bad) return go("reservations", bad, true);
    db.res.push({id:db.n.r++, table:t, guests:g, slot:f.slot, name:f.name.trim(), phone:f.phone.trim(), on:true}); go("reservations", "Reservation confirmed."); }
};
document.addEventListener("click", e => { const a = e.target.closest("[data-act]"); if (a && acts[a.dataset.act]) acts[a.dataset.act](a.dataset); });
document.addEventListener("submit", e => { e.preventDefault(); const f = e.target; if (forms[f.dataset.form]) forms[f.dataset.form](Object.fromEntries(new FormData(f))); });
document.addEventListener("input", e => { if (e.target.id !== "disc") return; const o = db.orders.find(x=>x.id===cur); let d = parseFloat(e.target.value); if (!(d >= 0 && d <= 100)) d = 0;
  const b = bill(sub(o), d); $("#vd").textContent = "-" + inr(b.disc); $("#vt").textContent = inr(b.tax); $("#vg").textContent = inr(b.total); });
render();
